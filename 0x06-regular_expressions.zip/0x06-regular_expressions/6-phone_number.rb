#!/usr/bin/env ruby
puts ARGV[0].scan(/^[1-9]\d{9}$/).join
