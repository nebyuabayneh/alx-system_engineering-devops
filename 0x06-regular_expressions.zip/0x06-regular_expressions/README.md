Learning REGEXP
